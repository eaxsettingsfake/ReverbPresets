# Reverb Presets

**English** | [العربية](README.ar.md)

A small VST2 effect for Windows: the 15 classic EAX environment reverb presets with an Effects Amount slider, followed by a 7-band graphic equalizer.

The reverb engine is a Rust re-implementation of the environmental reverb in the Sound Blaster EAX console. It was checked sample by sample against recordings of the original driver.

![Effects page](Images/Effects.png) ![Equalizer page](Images/Equalizer.png)

## Download

Ready-built plugins are in [`Release`](Release):

| File | For |
| --- | --- |
| `ReverbPresets64.dll` | 64-bit hosts (most DAWs, Equalizer APO) |
| `ReverbPresets32.dll` | 32-bit hosts |

Copy the one that matches your host into its VST2 plugin folder and rescan. The plugin shows up as **Reverb Presets**.

## What is inside

**Effects page**

- 15 presets: Auditorium, Ball Park, Bathroom, Cathedral, Chapel, Church, Concert Hall, Garage, Haunted Cavern, Indoor Arena, Jazz Club, Living Room, Opera House, Small Room, Theater.
- Effects Amount 0 to 100. Each preset keeps its own amount, starting from the console default (50, 60 or 65).
- Enable Audio Effects box and a Default button (Concert Hall, every preset back to its default amount).

**Equalizer page**

- 7 bands at 125, 250, 500, 1k, 2k, 4k and 8k Hz, each ±12 dB.
- Level slider, 0 to -24 dB.
- Presets list: Flat, Bass Boost, Treble Boost, Loudness, Vocal, Rock, Warm, Bright. Moving a slider by hand shows `<Custom>`.
- Enable Equalizer box and a Default button (flat and off).

The sound goes through the reverb first and the equalizer second.

## Host parameters

| # | Name | Range |
| --- | --- | --- |
| 0 | Preset | 15 steps |
| 1 | Amount | 0 to 100 |
| 2 | Enable | Off / On |
| 3 | EQ | Off / On |
| 4 to 10 | EQ 125 ... EQ 8k | -12 to +12 dB |
| 11 | Level | -24 to 0 dB |

The 15 presets are also exposed as host programs. The whole state, including every preset's own amount, is saved in the host project.

## Sample rates

At 44.1 kHz and 48 kHz the engine runs exactly as the original. The original engine stops at 48 kHz, so at higher rates the sound is filtered down to 48 kHz or below, run through the reverb there, and brought back up. That adds about 0.7 ms of delay to the reverb only. The dry sound is not touched.

## Building

You need Windows, Rust stable and the MSVC toolchain.

```
cargo build --release
cargo build --release --target i686-pc-windows-msvc
```

The 64-bit DLL lands in `target\release\ReverbPresets.dll` and the 32-bit one in `target\i686-pc-windows-msvc\release\ReverbPresets.dll`. The 32-bit build needs `rustup target add i686-pc-windows-msvc` once.

`cargo test --release` runs the tests.

The whole plugin is one source file, [`Source/ReverbPresets.rs`](Source/ReverbPresets.rs), with no dependencies outside the Rust standard library and Win32.

## License

Public domain, under [The Unlicense](LICENSE). Do anything you want with it.

Not affiliated with or endorsed by Creative Technology. Sound Blaster and EAX are trademarks of Creative Technology Ltd.
