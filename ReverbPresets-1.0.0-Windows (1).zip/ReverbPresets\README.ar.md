<div dir="rtl">

# Reverb Presets

[English](README.md) | **العربية**

إضافة صوتية صغيرة بصيغة VST2 لنظام ويندوز: الإعدادات الخمسة عشر الكلاسيكية لصدى EAX مع شريط لمقدار التأثير، يليها معادل صوت (Equalizer) من 7 نطاقات.

محرك الصدى مكتوب من جديد بلغة Rust، وهو نفس صدى البيئة الموجود في لوحة EAX الخاصة بكروت Sound Blaster. تمت مطابقته عينة بعينة مع تسجيلات من التعريف الأصلي.

![صفحة التأثيرات](Images/Effects.png) ![صفحة المعادل](Images/Equalizer.png)

## التحميل

الإضافة الجاهزة موجودة في مجلد [`Release`](Release):

| الملف | لمن |
| --- | --- |
| `ReverbPresets64.dll` | البرامج 64-بت (أغلب برامج الإنتاج الصوتي و Equalizer APO) |
| `ReverbPresets32.dll` | البرامج 32-بت |

انسخ الملف المناسب لبرنامجك إلى مجلد إضافات VST2 الخاص به ثم أعد البحث عن الإضافات. ستظهر الإضافة باسم **Reverb Presets**.

## ماذا بداخلها

**صفحة التأثيرات (Effects)**

- 15 إعدادًا: Auditorium و Ball Park و Bathroom و Cathedral و Chapel و Church و Concert Hall و Garage و Haunted Cavern و Indoor Arena و Jazz Club و Living Room و Opera House و Small Room و Theater.
- مقدار التأثير من 0 إلى 100. كل إعداد يحفظ مقداره الخاص، ويبدأ من القيمة الافتراضية للوحة الأصلية (50 أو 60 أو 65).
- مربع تشغيل التأثير وزر Default (يرجع إلى Concert Hall وكل إعداد إلى مقداره الافتراضي).

**صفحة المعادل (Equalizer)**

- 7 نطاقات عند 125 و 250 و 500 و 1k و 2k و 4k و 8k هيرتز، كل نطاق ±12 ديسيبل.
- شريط للمستوى (Level) من 0 إلى -24 ديسيبل.
- قائمة منحنيات جاهزة: Flat و Bass Boost و Treble Boost و Loudness و Vocal و Rock و Warm و Bright. عند تحريك أي شريط يدويًا يظهر `<Custom>`.
- مربع تشغيل المعادل وزر Default (يرجعه مستويًا ومطفأً).

الصوت يمر على الصدى أولًا ثم على المعادل.

## المتغيرات في البرنامج المضيف

| # | الاسم | المدى |
| --- | --- | --- |
| 0 | Preset | 15 خطوة |
| 1 | Amount | 0 إلى 100 |
| 2 | Enable | Off / On |
| 3 | EQ | Off / On |
| 4 إلى 10 | EQ 125 ... EQ 8k | -12 إلى +12 ديسيبل |
| 11 | Level | -24 إلى 0 ديسيبل |

الإعدادات الخمسة عشر تظهر أيضًا كبرامج (Programs) في البرنامج المضيف. الحالة كاملة، ومعها مقدار كل إعداد، تُحفظ داخل مشروع البرنامج المضيف.

## معدلات العينة

عند 44.1 و 48 كيلوهيرتز يعمل المحرك تمامًا مثل الأصلي. المحرك الأصلي لا يتجاوز 48 كيلوهيرتز، لذلك عند المعدلات الأعلى يُخفَّض الصوت إلى 48 كيلوهيرتز أو أقل، ويمر على الصدى هناك، ثم يُرفع مرة أخرى. هذا يضيف تأخيرًا بحوالي 0.7 ميلي ثانية على الصدى فقط، والصوت الأصلي لا يتأثر.

## البناء من الكود

تحتاج ويندوز و Rust stable وأدوات MSVC.

<div dir="ltr">

```
cargo build --release
cargo build --release --target i686-pc-windows-msvc
```

</div>

ملف 64-بت يكون في `target\release\ReverbPresets.dll` وملف 32-بت في `target\i686-pc-windows-msvc\release\ReverbPresets.dll`. بناء 32-بت يحتاج تشغيل `rustup target add i686-pc-windows-msvc` مرة واحدة.

الأمر `cargo test --release` يشغّل الاختبارات.

الإضافة كلها ملف كود واحد هو [`Source/ReverbPresets.rs`](Source/ReverbPresets.rs)، بدون أي مكتبات خارجية غير مكتبة Rust القياسية و Win32.

## الترخيص

ملكية عامة تحت [The Unlicense](LICENSE). افعل بها ما تريد.

هذا المشروع غير تابع لشركة Creative Technology ولا معتمد منها. Sound Blaster و EAX علامتان تجاريتان لشركة Creative Technology Ltd.

</div>
